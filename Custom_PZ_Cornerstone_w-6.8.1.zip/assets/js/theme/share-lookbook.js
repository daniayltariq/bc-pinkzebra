import PageManager from './page-manager';

export default class ShareLookbook extends PageManager {
    onReady() {
        console.log('hey');
    }
}
