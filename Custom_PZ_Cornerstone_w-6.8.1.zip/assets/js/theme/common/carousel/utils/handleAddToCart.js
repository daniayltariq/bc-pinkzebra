import { addToCart } from '../../../add-to-cart';

export default (context) => {
    addToCart(context);
};
